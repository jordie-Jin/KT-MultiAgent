# 로그 분석 자동화 시스템 — ERD 초안 (v0.1)

> 작성일 2026-06-17 · 범위: P0(필수) 중심, P1(확장)은 점선/별도 섹션
> 근거 문서: 아키텍처 다이어그램 1차 제출본 · 기획서 제출용 v0.2 · 에이전트 구성도 1차 · 보강이미지

---

## 1. 설계 방향

- **영속 대상은 "분석 결과"** 다 (기획서 P0-5). RDBMS에는 정형화된 로그, 이상 판정, 패턴 군집, 근거, 정확도 지표를 저장한다.
- **파이프라인 1회 실행 = `analysis_run`** 으로 묶는다. 리플레이/재실행(P1-4) 시 동일 로그에 대한 판정 이력을 분리 보관하기 위함.
- **정확도 검증(P0-6)** 은 `log_entry.true_label`(BGL 인라인 정답) vs `detection_result.predicted_label`(예측)을 run 단위로 집계해 `accuracy_metric`에 저장한다.
- **근거 설명(P0-3, 유일한 LLM Agent)** 은 이상으로 판정된 항목/패턴에 1:N으로 붙는다.
- **RAG(P1-2, ChromaDB)** 는 벡터 저장소라 RDBMS에는 직접 테이블을 두지 않고, 근거에 참조한 벡터 문서 ID만 남긴다.

---

## 2. ERD (Mermaid)

```mermaid
erDiagram
    ANALYSIS_RUN   ||--o{ LOG_ENTRY        : "포함"
    ANALYSIS_RUN   ||--o{ PATTERN_CLUSTER  : "생성"
    ANALYSIS_RUN   ||--o| ACCURACY_METRIC  : "집계"
    LOG_ENTRY      ||--o| DETECTION_RESULT : "판정"
    PATTERN_CLUSTER ||--o{ PATTERN_MEMBER  : "구성"
    DETECTION_RESULT ||--o{ PATTERN_MEMBER : "소속"
    DETECTION_RESULT ||--o{ EVIDENCE       : "근거"
    PATTERN_CLUSTER  ||--o{ EVIDENCE       : "패턴근거"

    ANALYSIS_RUN {
        bigint   run_id PK
        varchar  name
        varchar  source        "BGL 파일/데이터셋 식별"
        varchar  status        "RUNNING|DONE|FAILED"
        int      total_logs
        json     params        "탐지 규칙/윈도우 등 실행 파라미터"
        datetime started_at
        datetime finished_at
    }

    LOG_ENTRY {
        bigint   log_id PK
        bigint   run_id FK
        text     raw_text      "원본 로그 라인"
        text     message       "정형화 메시지"
        datetime log_ts        "로그 타임스탬프"
        varchar  node          "노드/컴포넌트"
        varchar  severity      "INFO|WARN|ERROR 등"
        varchar  true_label    "BGL 인라인 정답: NORMAL|ANOMALY (P0-6)"
        int      chunk_seq     "청크 분할 순번 (P0-1)"
    }

    DETECTION_RESULT {
        bigint   detection_id PK
        bigint   log_id FK
        bigint   run_id FK
        varchar  predicted_label "NORMAL|ANOMALY (P0-2)"
        varchar  matched_rule    "키워드/빈도/윈도우 규칙명"
        float    score
        datetime detected_at
    }

    PATTERN_CLUSTER {
        bigint   pattern_id PK
        bigint   run_id FK
        text     template      "추출 템플릿/시그니처 (P0-4)"
        varchar  severity
        int      member_count
        datetime first_seen
        datetime last_seen
    }

    PATTERN_MEMBER {
        bigint   pattern_id FK
        bigint   detection_id FK
        float    distance      "클러스터 중심 거리(선택)"
    }

    EVIDENCE {
        bigint   evidence_id PK
        bigint   detection_id FK "이상 로그 단위 근거(nullable)"
        bigint   pattern_id FK   "패턴 단위 근거(nullable)"
        text     content         "왜 문제인지 자연어 근거 (P0-3)"
        varchar  model           "사용 LLM 모델"
        float    confidence
        varchar  rag_ref         "ChromaDB 참조 문서 ID (P1-2, nullable)"
        datetime created_at
    }

    ACCURACY_METRIC {
        bigint   metric_id PK
        bigint   run_id FK
        int      tp
        int      fp
        int      fn
        int      tn
        float    precision
        float    recall
        float    f1
        datetime computed_at
    }
```

---

## 3. 엔티티 요약

| 엔티티 | 역할 | 대응 기능 |
|---|---|---|
| `analysis_run` | 파이프라인 1회 실행 단위 | 전체 흐름 |
| `log_entry` | 정형화된 로그 + 정답 라벨 | P0-1 파서, P0-6 정답 |
| `detection_result` | 규칙 기반 이상 판정 | P0-2 이상 탐지 |
| `pattern_cluster` | 반복 이상 패턴 군집 | P0-4 군집화 |
| `pattern_member` | 판정↔패턴 N:M 연결 | P0-4 |
| `evidence` | LLM 자연어 근거 | P0-3 근거 설명 |
| `accuracy_metric` | run 단위 P/R/F1 | P0-6 정확도 검증 |

---

## 4. 주요 관계 / 카디널리티

- `analysis_run` 1 : N `log_entry` — 한 실행에 다수 로그
- `log_entry` 1 : 0..1 `detection_result` — 로그당 판정 1건 (재실행 시 새 run으로 분리)
- `pattern_cluster` N : M `detection_result` (via `pattern_member`) — 한 패턴은 여러 이상 로그를, 한 로그는 여러 패턴 후보에 속할 수 있음
- `detection_result` 1 : N `evidence` / `pattern_cluster` 1 : N `evidence` — 근거는 로그 단위 또는 패턴 단위로 부착(둘 중 하나가 NULL)
- `analysis_run` 1 : 0..1 `accuracy_metric` — run 종료 시 1건 산출

---

## 5. P1(확장) 후보 — 점선 영역, 후속 추가

```mermaid
erDiagram
    APP_USER         ||--o{ ACTION_REVIEW  : "검토"
    DETECTION_RESULT ||--o{ ACTION_REC     : "권고"
    ACTION_REC       ||--o| ACTION_REVIEW  : "승인대상"

    APP_USER {
        bigint  user_id PK
        varchar username
        varchar password_hash "JWT 인증 (P1-5)"
        varchar role
    }
    ACTION_REC {
        bigint  action_id PK
        bigint  detection_id FK
        text    recommendation "조치 권고 (보강이미지 Action Advisor)"
        datetime created_at
    }
    ACTION_REVIEW {
        bigint  review_id PK
        bigint  action_id FK
        bigint  user_id FK
        varchar decision "APPROVED|REJECTED (HITL P1-6)"
        text    comment
        datetime reviewed_at
    }
```

- **ChromaDB(P1-2)**: 벡터 저장소이므로 RDBMS 외부. `evidence.rag_ref`로만 연결.
- **다중 에이전트 실패 격리(P1-7)**: 필요 시 `agent_run`(에이전트별 상태/실패 격리 로그) 테이블 추가 검토.

---

## 6. 확정 필요 사항 (검토 요청)

1. **근거(evidence) 부착 단위**: 이상 로그 단위 vs 패턴 단위 — 현재는 둘 다 허용. 한쪽으로 고정할지?
2. **재실행/리플레이 모델**: 동일 로그를 run마다 새 `log_entry`로 복제할지, `log_entry`는 1벌만 두고 `detection_result`만 run별로 분리할지?
3. **정확도 지표 단위**: run 전체 1건만 둘지, 패턴/심각도별로도 쪼갤지?
4. **BGL 스키마**: `node`, `severity` 외에 BGL 특유 필드(예: 위치코드, 이벤트 타입) 정형화 범위 확정 필요.
