# 로그 분석 시스템 — 백엔드/DB ERD · API 명세 초안 (v0.1)

> 작성일 2026-06-17 · 담당: Back + DB
> 범위: Front ↔ Back(Spring Boot) ↔ DB(RDBMS) 3-Tier 중 **DB 스키마 + REST API**
> 제외: 분석 에이전트 파이프라인 내부(이상탐지/근거설명/정확도) — **다른 팀 담당**
> 전제: 분석 엔진이 `log`·`pattern` 테이블에 결과를 적재(write)하고, 백엔드는 이를 조회(read)해 화면에 내려준다.

---

## 1. 화면 → 데이터 → 출처 매핑

| 화면 | 영역 | 기간 영향 | 데이터 출처 |
|---|---|:---:|---|
| **대시보드** | 총 로그 수 | O | `log` count |
| | 주의 로그 수 | O | `log` where label=WARNING |
| | 시간대별 로그 발생량 | O | `log` 시간 버킷 집계 |
| | 레벨 분포 | O | `log` level 집계 |
| | 컴포넌트별 로그 수 | O | `log` component 집계 |
| | 최근 주의 로그 | **X** | `log` where label=WARNING, 최신순 |
| | 주요 패턴 | **X** | `pattern` 발생순 |
| **시스템 로그** | 로그 목록(기본 24h, 달력 선택) | O | `log` 목록 |
| **주의 로그 분석** | 라벨 기준 로그 목록 | O | `log` where label=WARNING |
| **패턴 분석** | 패턴 목록/상세 | X | `pattern` (+ `pattern_log`) |

→ 필요한 테이블은 **`log`, `pattern`** 2개 + 패턴 상세용 매핑 **`pattern_log`**(선택).

---

## 2. 기간(period) 처리 규칙

- **기간 계산은 프론트 책임**, 백엔드는 `from`/`to`(ISO-8601) 범위만 받아 `log_ts BETWEEN from AND to`로 조회.
- 대시보드/시스템 로그 기본값: `to = 현재시각`, `from = 현재시각 - 24h`.
- 달력에서 특정 일자(D) 선택 시(현재가 25일 14시, 23일 선택 예): 프론트가 `from = (D-1) 14:00`, `to = D 14:00` 로 계산해 전송. → 백엔드는 동일한 범위 조회 로직 재사용.
- 시간대 전제: 모든 timestamp는 ISO-8601, 서버는 단일 타임존(KST) 기준 해석. (확정 필요 — 6장)

---

## 3. DB 테이블 스키마

### 3.1 `log` — 로그 원본/정형화 레코드

| 컬럼 | 타입 | NULL | 키 | 설명 |
|---|---|:---:|:---:|---|
| `log_id` | BIGINT (auto inc) | N | PK | 로그 식별자 |
| `log_ts` | DATETIME(6) | N | IDX | 로그 발생 시각 — 모든 기간 조회 기준 |
| `level` | VARCHAR(10) | N | IDX | 로그 레벨: INFO / WARN / ERROR / FATAL / DEBUG (레벨 분포) |
| `component` | VARCHAR(100) | Y | IDX | 컴포넌트/서비스명 (컴포넌트별 집계) |
| `label` | VARCHAR(20) | N | IDX | 분석 라벨: `NORMAL` / `WARNING` (주의 로그 분류, 분석엔진 산출) |
| `message` | TEXT | Y | | 정형화 메시지 본문 |
| `raw_text` | TEXT | Y | | 원본 로그 라인 (옵션) |
| `node` | VARCHAR(100) | Y | | 노드/호스트 (옵션) |
| `created_at` | DATETIME(6) | N | | DB 적재 시각 (default now) |

**인덱스 (조회 성능 핵심)**
```sql
CREATE INDEX idx_log_ts            ON log (log_ts);
CREATE INDEX idx_log_label_ts      ON log (label, log_ts);     -- 주의 로그/최근 주의 로그
CREATE INDEX idx_log_level_ts      ON log (level, log_ts);     -- 레벨 분포
CREATE INDEX idx_log_component_ts  ON log (component, log_ts); -- 컴포넌트별 집계
```

### 3.2 `pattern` — 군집된 이상 패턴

| 컬럼 | 타입 | NULL | 키 | 설명 |
|---|---|:---:|:---:|---|
| `pattern_id` | BIGINT (auto inc) | N | PK | 패턴 식별자 |
| `title` | VARCHAR(200) | Y | | 패턴 요약명 |
| `template` | TEXT | N | | 패턴 시그니처/템플릿 |
| `severity` | VARCHAR(20) | Y | | LOW / MEDIUM / HIGH |
| `label` | VARCHAR(20) | Y | | 관련 라벨 |
| `occurrence_count` | INT | N | IDX | 발생 횟수 (주요 패턴 정렬 기준) |
| `first_seen` | DATETIME(6) | Y | | 최초 발생 |
| `last_seen` | DATETIME(6) | Y | IDX | 최근 발생 |
| `created_at` | DATETIME(6) | N | | 적재 시각 |

```sql
CREATE INDEX idx_pattern_count     ON pattern (occurrence_count DESC);
CREATE INDEX idx_pattern_last_seen ON pattern (last_seen DESC);
```

### 3.3 `pattern_log` — 패턴↔로그 매핑 (선택, 패턴 상세 드릴다운용)

| 컬럼 | 타입 | NULL | 키 | 설명 |
|---|---|:---:|:---:|---|
| `pattern_id` | BIGINT | N | PK/FK→pattern | |
| `log_id` | BIGINT | N | PK/FK→log | |

> 패턴 상세에서 소속 로그를 보여줄 때만 필요. "패턴 테이블 데이터만 쏴주면 된다"는 요구만이면 생략 가능.

---

## 4. REST API 명세

공통: `Content-Type: application/json`, 시각은 ISO-8601(`2026-06-17T14:00:00`), 목록은 `page`(0-base)/`size` 페이지네이션.

### 4.1 대시보드 — 기간 영향 영역 (1회 호출로 통합)

```
GET /api/dashboard?from={ISO}&to={ISO}&interval=HOUR
```
응답:
```json
{
  "period": { "from": "2026-06-16T14:00:00", "to": "2026-06-17T14:00:00" },
  "summary": { "totalLogs": 12345, "warningLogs": 234 },
  "timeline": [
    { "time": "2026-06-16T14:00:00", "count": 120 },
    { "time": "2026-06-16T15:00:00", "count": 98 }
  ],
  "levelDistribution": [
    { "level": "INFO", "count": 11000 },
    { "level": "WARN", "count": 1100 },
    { "level": "ERROR", "count": 245 }
  ],
  "componentDistribution": [
    { "component": "auth-service", "count": 3400 },
    { "component": "payment-service", "count": 2100 }
  ]
}
```

### 4.2 대시보드 — 기간 비영향 영역

```
GET /api/dashboard/recent-warnings?limit=10
```
```json
{
  "items": [
    { "logId": 90213, "logTs": "2026-06-17T13:58:21", "level": "ERROR",
      "component": "payment-service", "label": "WARNING",
      "message": "connection pool exhausted" }
  ]
}
```

```
GET /api/dashboard/top-patterns?limit=5
```
```json
{
  "items": [
    { "patternId": 12, "title": "DB connection timeout", "severity": "HIGH",
      "occurrenceCount": 152, "lastSeen": "2026-06-17T13:40:00" }
  ]
}
```

### 4.3 시스템 로그 — 목록

```
GET /api/logs?from={ISO}&to={ISO}&page=0&size=50&level={opt}&component={opt}&keyword={opt}
```
- `from`/`to` 미전달 시 서버 기본값 = 최근 24시간.
- `level`, `component`, `keyword`(message LIKE) 선택 필터.

```json
{
  "page": 0, "size": 50, "totalElements": 1234, "totalPages": 25,
  "content": [
    { "logId": 90201, "logTs": "2026-06-17T13:55:01", "level": "INFO",
      "component": "auth-service", "label": "NORMAL", "message": "user login ok" }
  ]
}
```

### 4.4 주의 로그 분석 — 라벨 기준 목록

```
GET /api/warnings?from={ISO}&to={ISO}&page=0&size=50&label=WARNING
```
- `log` 테이블을 `label` 기준으로 조회 (기본 `label=WARNING`).
- 응답 형태는 4.3과 동일(`content[]`).

> 시스템 로그(4.3)에 `label` 필터를 추가해 통합할 수도 있음. 화면이 별도이므로 전용 엔드포인트로 분리.

### 4.5 패턴 분석 — 목록/상세

```
GET /api/patterns?page=0&size=20&sort=occurrenceCount,desc
```
```json
{
  "page": 0, "size": 20, "totalElements": 87, "totalPages": 5,
  "content": [
    { "patternId": 12, "title": "DB connection timeout", "template": "...",
      "severity": "HIGH", "label": "WARNING", "occurrenceCount": 152,
      "firstSeen": "2026-06-15T02:11:00", "lastSeen": "2026-06-17T13:40:00" }
  ]
}
```

```
GET /api/patterns/{patternId}
```
```json
{
  "patternId": 12, "title": "DB connection timeout", "template": "...",
  "severity": "HIGH", "label": "WARNING", "occurrenceCount": 152,
  "firstSeen": "2026-06-15T02:11:00", "lastSeen": "2026-06-17T13:40:00",
  "sampleLogs": [
    { "logId": 90213, "logTs": "2026-06-17T13:40:00", "component": "payment-service",
      "message": "connection pool exhausted" }
  ]
}
```
> `sampleLogs`는 `pattern_log` 매핑이 있을 때만. 없으면 상세에서 제외.

---

## 5. API 요약표

| 화면 | Method | Path | 기간 |
|---|:---:|---|:---:|
| 대시보드(차트) | GET | `/api/dashboard` | O |
| 대시보드(최근 주의 로그) | GET | `/api/dashboard/recent-warnings` | X |
| 대시보드(주요 패턴) | GET | `/api/dashboard/top-patterns` | X |
| 시스템 로그 | GET | `/api/logs` | O |
| 주의 로그 분석 | GET | `/api/warnings` | O |
| 패턴 분석(목록) | GET | `/api/patterns` | X |
| 패턴 분석(상세) | GET | `/api/patterns/{id}` | X |

모두 조회(GET)만 — 화면은 읽기 전용. (데이터 적재는 분석 엔진 담당)

---

## 6. 확정 사항 (v0.2)

> 기본값으로 확정. 팀 합의로 변경 가능.

| # | 항목 | 결정 | 근거 |
|---|---|---|---|
| 1 | **타임존** | **KST(Asia/Seoul) 고정** — DB `datetime` 저장·조회·프론트 `from`/`to` 모두 KST | 국내 단일 운영, 변환 복잡도 제거. 추후 글로벌 시 UTC 저장으로 마이그레이션 |
| 2 | **`label` 값** | **`NORMAL` / `WARNING` 2단계**, 컬럼은 `varchar(20)` 유지 | 화면이 "총 로그 / 주의 로그" 2분류. 컬럼 길이로 `ANOMALY`/`CRITICAL` 확장 여지 확보 |
| 3 | **`level` vs `label`** | **별도 축으로 분리 확정** — `level`=원시 심각도(INFO/WARN/ERROR), `label`=분석 판정(NORMAL/WARNING) | 레벨 분포와 주의 로그 집계가 서로 다른 화면 영역 |
| 4 | **패턴 드릴다운** | **`pattern_log` 유지** — 패턴 상세에서 소속 로그 제공 | 비용 작고 활용도 높음. 상세 화면 `sampleLogs` 지원 |
| 5 | **시간 버킷** | **기본 `HOUR`, `interval` 파라미터로 가변(`HOUR`\|`DAY`)** | 24h는 시간 단위, 장기 조회 대비 일 단위 옵션 |
| 6 | **로그 엔드포인트** | **`/api/logs`와 `/api/warnings` 분리 유지**, 내부 쿼리는 공유 | 화면이 분리(시스템 로그 / 주의 로그 분석)되어 의미 명확 |
