# -*- coding: utf-8 -*-
"""로그 분석 자동화 시스템 기획서 PDF 생성 스크립트 (v0.2)

사용법:
    python make_plan_pdf.py            # 내부용 (안내 박스 포함)
    python make_plan_pdf.py --submit   # 제출용 (내수용 노란/빨간 박스 제거)
"""
import os
import sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable,
)
from reportlab.lib.styles import ParagraphStyle

# --- 한글 폰트 등록 (맑은 고딕) ---
pdfmetrics.registerFont(TTFont("Malgun", r"C:\Windows\Fonts\malgun.ttf"))
pdfmetrics.registerFont(TTFont("MalgunBd", r"C:\Windows\Fonts\malgunbd.ttf"))
pdfmetrics.registerFontFamily("Malgun", normal="Malgun", bold="MalgunBd")

SUBMIT = "--submit" in sys.argv
OUT_NAME = ("로그분석_자동화시스템_기획서_제출용.pdf" if SUBMIT
            else "로그분석_자동화시스템_기획서.pdf")
OUT = os.path.join(os.path.dirname(__file__), OUT_NAME)

# --- 색상 ---
PRIMARY = colors.HexColor("#1F4E79")
ACCENT = colors.HexColor("#2E75B6")
GREY = colors.HexColor("#595959")
CALLOUT_BG = colors.HexColor("#FBF3E0")   # 우선순위 원칙 / 정확도 박스
CALLOUT_BD = colors.HexColor("#E0B84C")
WARN_BG = colors.HexColor("#FDEDEC")      # 과설계 경고 박스
WARN_BD = colors.HexColor("#D98880")
ROW_ALT = colors.HexColor("#EEF3F9")
GRID = colors.HexColor("#C9D4E3")

# --- 스타일 ---
styles = {}
styles["title"] = ParagraphStyle(
    "title", fontName="MalgunBd", fontSize=19, leading=24,
    textColor=PRIMARY, spaceAfter=2)
styles["subtitle"] = ParagraphStyle(
    "subtitle", fontName="Malgun", fontSize=10, leading=14,
    textColor=GREY, spaceAfter=4)
styles["h2"] = ParagraphStyle(
    "h2", fontName="MalgunBd", fontSize=13, leading=17,
    textColor=PRIMARY, spaceBefore=11, spaceAfter=5)
styles["h3"] = ParagraphStyle(
    "h3", fontName="MalgunBd", fontSize=10.5, leading=14,
    textColor=ACCENT, spaceBefore=6, spaceAfter=2)
styles["body"] = ParagraphStyle(
    "body", fontName="Malgun", fontSize=10, leading=15,
    textColor=colors.HexColor("#222222"), alignment=TA_LEFT, spaceAfter=2)
styles["cell"] = ParagraphStyle(
    "cell", fontName="Malgun", fontSize=9, leading=12.5,
    textColor=colors.HexColor("#222222"), alignment=TA_LEFT)
styles["cellhdr"] = ParagraphStyle(
    "cellhdr", fontName="MalgunBd", fontSize=9, leading=12.5,
    textColor=colors.white, alignment=TA_LEFT)
styles["bullet"] = ParagraphStyle(
    "bullet", fontName="Malgun", fontSize=10, leading=15,
    textColor=colors.HexColor("#222222"), leftIndent=12, bulletIndent=2,
    spaceAfter=2)
styles["callout"] = ParagraphStyle(
    "callout", fontName="Malgun", fontSize=9.5, leading=14,
    textColor=colors.HexColor("#5A4A1A"))
styles["warn"] = ParagraphStyle(
    "warn", fontName="Malgun", fontSize=9.5, leading=14,
    textColor=colors.HexColor("#7B241C"))
styles["boxwhite"] = ParagraphStyle(
    "boxwhite", fontName="Malgun", fontSize=9.5, leading=14,
    textColor=colors.white)
styles["meta"] = ParagraphStyle(
    "meta", fontName="Malgun", fontSize=9, leading=12, textColor=GREY)


def bullet(text):
    return Paragraph(f"• {text}", styles["bullet"])


def callout(text, bg=CALLOUT_BG, bd=CALLOUT_BD, st="callout"):
    """배경색 + 좌측 강조선이 있는 안내 박스."""
    inner = Paragraph(text, styles[st])
    t = Table([[inner]], colWidths=[170 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg),
        ("BOX", (0, 0), (-1, -1), 0.6, bd),
        ("LINEBEFORE", (0, 0), (0, -1), 3, bd),
        ("LEFTPADDING", (0, 0), (-1, -1), 9),
        ("RIGHTPADDING", (0, 0), (-1, -1), 9),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return t


def make_table(header, rows, col_widths):
    data = [[Paragraph(h, styles["cellhdr"]) for h in header]]
    for r in rows:
        data.append([Paragraph(c, styles["cell"]) for c in r])
    t = Table(data, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), PRIMARY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, ROW_ALT]),
        ("GRID", (0, 0), (-1, -1), 0.4, GRID),
    ]))
    return t


# --- 아키텍처 다이어그램 (3-Tier) 헬퍼 ---
PAGE_W = 170 * mm
# (배경, 테두리, 글자) 색
BOX_STYLES = {
    "p0": (colors.HexColor("#DBEAFE"), colors.HexColor("#1D4ED8"), colors.HexColor("#0F172A")),
    "p1": (colors.HexColor("#FEF3C7"), colors.HexColor("#D97706"), colors.HexColor("#7C5A12")),
    "agent": (colors.HexColor("#EDE9FE"), colors.HexColor("#7C3AED"), colors.HexColor("#3B0764")),
    "gw": (colors.HexColor("#CCFBF1"), colors.HexColor("#0D9488"), colors.HexColor("#134E4A")),
    "data": (colors.HexColor("#DCFCE7"), colors.HexColor("#16A34A"), colors.HexColor("#14532D")),
}
ARROW_STYLE = ParagraphStyle(
    "arrow", fontName="MalgunBd", fontSize=12, leading=13,
    textColor=ACCENT, alignment=TA_CENTER)


def _boxpara(text, fg):
    return Paragraph(text, ParagraphStyle(
        "bx", fontName="Malgun", fontSize=7.5, leading=9.5,
        textColor=fg, alignment=TA_CENTER))


def flow_row(items, total_w=PAGE_W, connector="→", row_h=12 * mm):
    """[box]→[box]→... 한 줄. items=[(text, kind), ...]."""
    cells, kinds = [], []
    for i, (text, kind) in enumerate(items):
        if i > 0:
            cells.append(Paragraph(connector, ARROW_STYLE))
            kinds.append(None)
        fg = BOX_STYLES[kind][2]
        cells.append(_boxpara(f"<b>{text}</b>", fg))
        kinds.append(kind)
    conn_w = 7 * mm if connector.strip() else 4 * mm
    n_box = sum(1 for k in kinds if k)
    n_conn = sum(1 for k in kinds if k is None)
    box_w = (total_w - n_conn * conn_w) / n_box
    widths = [conn_w if k is None else box_w for k in kinds]
    t = Table([cells], colWidths=widths, rowHeights=[row_h])
    st = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    for idx, k in enumerate(kinds):
        if k:
            bg, bd, _ = BOX_STYLES[k]
            st.append(("BACKGROUND", (idx, 0), (idx, 0), bg))
            st.append(("BOX", (idx, 0), (idx, 0), 1, bd))
    t.setStyle(TableStyle(st))
    return t


def tier_bar(text, bg):
    p = Paragraph(f"<b>{text}</b>", ParagraphStyle(
        "tier", fontName="MalgunBd", fontSize=9.5, leading=12, textColor=colors.white))
    t = Table([[p]], colWidths=[PAGE_W])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def sublabel(text):
    return Paragraph(text, ParagraphStyle(
        "sub", fontName="MalgunBd", fontSize=8.5, leading=11,
        textColor=GREY, spaceBefore=3, spaceAfter=2))


def p1_bar(text):
    p = Paragraph(text, ParagraphStyle(
        "p1b", fontName="Malgun", fontSize=8, leading=11,
        textColor=colors.HexColor("#7C5A12")))
    t = Table([[p]], colWidths=[PAGE_W])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFFBEB")),
        ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#D97706")),
        ("LINEBEFORE", (0, 0), (0, -1), 3, colors.HexColor("#D97706")),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def down_arrow():
    return Paragraph("&#8595;", ParagraphStyle(
        "down", fontName="MalgunBd", fontSize=13, leading=15,
        textColor=ACCENT, alignment=TA_CENTER, spaceBefore=2, spaceAfter=2))


def arch_diagram():
    """Top-Down 3-Tier 아키텍처 다이어그램 flowable 목록."""
    f = []
    # ① Presentation
    f.append(tier_bar("① Presentation Tier · React 대시보드 (MVP 패턴)",
                      colors.HexColor("#0C4A6E")))
    f.append(Spacer(1, 3))
    f.append(flow_row([("View<br/>대시보드·목록·상세 화면", "p0"),
                       ("Presenter<br/>표시·이벤트 조율", "p0"),
                       ("Model<br/>API 응답 모델", "p0")], connector="↔"))
    f.append(Spacer(1, 2))
    f.append(p1_bar("P1 확장 · 로그인·접근제어 (P1-5)"))
    f.append(down_arrow())
    # ② Application
    f.append(tier_bar("② Application Tier", colors.HexColor("#374151")))
    f.append(sublabel("Spring Boot API · Controller → Service → Repository"))
    f.append(flow_row([("Controller<br/>대시보드·목록·상세·정확도 API", "p0"),
                       ("Service<br/>분석 오케스트레이션·조회", "p0"),
                       ("Repository<br/>RDBMS 접근", "p0")], connector="→"))
    f.append(sublabel("Python 분석 엔진 · FastAPI 게이트웨이 → 결정적 Tool ↔ LLM Agent (Spring Boot ⇄ FastAPI 요청·응답)"))
    f.append(flow_row([("FastAPI<br/>분석 요청 엔드포인트", "gw"),
                       ("로그 파서<br/>Tool · P0-1", "p0"),
                       ("이상 탐지<br/>규칙 Tool · P0-2", "p0"),
                       ("패턴 군집화<br/>알고리즘 Tool · P0-4", "p0"),
                       ("근거 설명<br/>LLM Agent · P0-3", "agent"),
                       ("정확도 검증<br/>모듈 · P0-6", "p0")], connector="→"))
    f.append(Spacer(1, 2))
    f.append(p1_bar("P1 확장 · JWT 인증(P1-5) · HITL 승인(P1-6) · Tool 호출구조(P1-1) · "
                    "통계 이상탐지(P1-3) · 리플레이(P1-4) · 다중에이전트 실패격리(P1-7)"))
    f.append(down_arrow())
    # ③ Data
    f.append(tier_bar("③ Data Tier", colors.HexColor("#14532D")))
    f.append(Spacer(1, 3))
    f.append(flow_row([("RDBMS<br/>분석결과 영속 · P0-5", "data"),
                       ("BGL 로그 입력<br/>라벨 포함", "data"),
                       ("ChromaDB<br/>과거사례 벡터 · P1-2", "p1")], connector=" "))
    return f


doc = SimpleDocTemplate(
    OUT, pagesize=A4,
    leftMargin=20 * mm, rightMargin=20 * mm,
    topMargin=16 * mm, bottomMargin=15 * mm,
    title="로그 분석 자동화 시스템 기획서")

story = []

# --- 헤더 ---
story.append(Paragraph("로그 분석 자동화 시스템 기획서", styles["title"]))
story.append(Paragraph(
    "멀티 에이전트 기반 운영 로그 장애 징후 탐지 · 조치 응답 시스템", styles["subtitle"]))

meta_tbl = Table(
    [[Paragraph("작성일&nbsp;&nbsp;2026-06-15", styles["meta"]),
      Paragraph("문서버전&nbsp;&nbsp;v0.2", styles["meta"]),
      Paragraph("범위&nbsp;&nbsp;기획서 (상세 설계는 설계문서)", styles["meta"])]],
    colWidths=[55 * mm, 50 * mm, 65 * mm])
meta_tbl.setStyle(TableStyle([
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("LEFTPADDING", (0, 0), (-1, -1), 0),
    ("TOPPADDING", (0, 0), (-1, -1), 2),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
]))
story.append(meta_tbl)
story.append(Spacer(1, 4))
story.append(HRFlowable(width="100%", thickness=1.2, color=ACCENT))
story.append(Spacer(1, 6))

# --- 우선순위 원칙 박스 (내수용 — 제출용에서는 제외) ---
if not SUBMIT:
    story.append(callout(
        "<b>우선순위 원칙</b> &mdash; P0(필수)를 <b>먼저 100% 동작</b>시켜 E2E로 관통(≈6/22 목표)한 "
        "뒤, P1(확장)은 그 이후 여력으로만 착수한다. RFP 평가는 필수 전 항목 동작이 <b>기준선</b>, "
        "확장은 <b>가산점</b>이다. 일정에서도 P1을 P0 뒤로 물린다."))
    story.append(Spacer(1, 4))

# --- 1. 동기 및 목적 ---
story.append(Paragraph("1. 동기 및 목적", styles["h2"]))
story.append(Paragraph("문제 정의", styles["h3"]))
story.append(Paragraph(
    "서비스가 정상 운영 중에도 운영 로그는 끊임없이 쌓인다. 기존 레거시 환경에서는 담당자가 온콜을 받고 "
    "수동으로 로그를 확인하는 다단계 프로세스를 거친다. 이 방식은 두 가지 구조적 문제를 가진다.",
    styles["body"]))
story.append(bullet(
    "<b>탐지 지연:</b> 사람이 로그를 일일이 훑는 구조에서는 장애 징후를 제때 발견하기 어렵다. "
    "사후에 알아차리면 이미 서비스 중단이나 사용자 피해가 발생한 이후다."))
story.append(bullet(
    "<b>패턴 한계:</b> 사전에 정의된 규칙과 패턴으로만 필터링하기 때문에 예상치 못한 예외 상황에 "
    "대응하기 어렵다. 같은 장애가 반복되어도 담당자 간 경험이 공유되지 않아 원인 추적이 어렵다."))
story.append(Paragraph("해결 방향", styles["h3"]))
story.append(Paragraph(
    "멀티 에이전트 기반으로 로그 분석 전 과정을 자동화한다. 단순 규칙 필터링을 넘어 이상치 패턴을 "
    "동적으로 탐지하고, 어떤 로그가 왜 문제인지 근거를 자동 생성한다. 분석 결과는 영속적으로 "
    "보관되어 조직의 지식 자산으로 축적된다.", styles["body"]))
story.append(Paragraph("타겟", styles["h3"]))
story.append(Paragraph(
    "MSA·Cloud·Kubernetes 환경에서 운영 로그를 수동으로 관리하는 SRE·DevOps 담당자.",
    styles["body"]))

# --- 2. 핵심 기능 목록 ---
story.append(Paragraph("2. 핵심 기능 목록 (우선순위 순)", styles["h2"]))
story.append(Paragraph("P0 — 필수 (평가 기준선)", styles["h3"]))
p0_rows = [
    ["P0-1", "로그 파서", "Tool",
     "BGL 로그 수신, 라벨 분리, 정형화, 청크 분할"],
    ["P0-2", "이상 탐지", "<b>결정적 Tool</b><br/>(규칙 기반)",
     "키워드·빈도·시간 윈도우 규칙으로 정상·이상 구분. LLM이 아닌 결정적 규칙으로 판정해 F1 재현성 확보"],
    ["P0-3", "근거 설명 <b>Agent</b>", "<b>LLM Agent</b>",
     "이상 로그에 대해 \"왜 문제인지\" 자연어로 근거 생성 (유일한 진짜 LLM 에이전트)"],
    ["P0-4", "패턴 군집화", "<b>알고리즘 Tool</b>",
     "템플릿 추출·클러스터링으로 반복 이상 패턴을 묶어 같은 성격의 장애 징후를 한데 제시"],
    ["P0-5", "분석 결과 저장·조회", "Service",
     "RDBMS 영속 저장, 목록·상세 조회 API, 대시보드 API"],
    ["P0-6", "정확도 검증", "모듈",
     "BGL 인라인 라벨로 Precision·Recall·F1 측정 및 화면 표시"],
]
story.append(make_table(
    ["순위", "기능", "구현 형태", "설명"], p0_rows,
    [16 * mm, 30 * mm, 28 * mm, 96 * mm]))
# --- 과설계 방지 박스 (내수용 — 제출용에서는 제외) ---
if not SUBMIT:
    story.append(Spacer(1, 5))
    story.append(callout(
        "<b>[과설계 방지]</b> 진짜 LLM 에이전트가 필요한 건 <b>P0-3(근거 설명) 하나뿐</b>이다. "
        "이상 탐지(P0-2)·패턴 군집화(P0-4)까지 LLM으로 돌리면 느리고·비싸고·판정이 흔들려 "
        "정확도(F1) 재현이 불가능해진다. RFP 2.2가 그린 <b>\"규칙=도구, 에이전트=근거 추론\"</b> "
        "구조에 맞춰 결정적 Tool과 LLM Agent를 분리한다. (자세한 구조는 §3 참조)",
        bg=WARN_BG, bd=WARN_BD, st="warn"))
story.append(Spacer(1, 6))

story.append(Paragraph("P1 — 확장 (우대 항목)", styles["h3"]))
story.append(Paragraph(
    "P1은 P0 전체가 E2E로 동작한 이후 여력으로만 착수한다.", styles["meta"]))
story.append(Spacer(1, 2))
p1_rows = [
    ["P1-1", "Tool 호출 구조", "탐지 규칙을 코드 고정이 아닌 에이전트 호출 도구(Tool)로 분리"],
    ["P1-2", "RAG (ChromaDB)",
     "과거 유사 사례를 검색해 근거 설명 품질 향상 — <b>RAG 챗봇이 아니라</b> 근거 보강용 검색 모듈"],
    ["P1-3", "통계 이상 탐지", "Z-score·IQR 기반 정상 기준 학습 후 이상 탐지"],
    ["P1-4", "리플레이 시뮬레이터", "저장 로그를 시간순 재생, 이상 감지 시점 알림"],
    ["P1-5", "로그인·접근 제어", "JWT 인증, 허가된 사용자만 결과 조회"],
    ["P1-6", "Human-in-the-Loop",
     "Action Advisor 권고를 담당자가 승인·거절하는 검토 흐름 — <b>권고만 제시하며 실제 시스템 "
     "실행·제어는 하지 않음</b> (RFP 운영 제어·자동 복구 제외 준수)"],
    ["P1-7", "다중 에이전트 협업·실패 격리",
     "1차 탐지와 근거 설명을 다수 에이전트로 분리·협업하고, <b>일부 처리가 실패해도 전체가 "
     "중단되지 않도록</b> 격리 처리 (RFP 확장 핵심)"],
]
story.append(make_table(
    ["순위", "기능", "설명"], p1_rows,
    [16 * mm, 40 * mm, 114 * mm]))
story.append(Spacer(1, 5))
story.append(Paragraph("구현 제외", styles["h3"]))
story.append(bullet("운영 시스템 제어·자동 복구 실행 (RFP 명시 제외)"))
story.append(bullet("실서비스 실시간 직접 감시 (리플레이 시뮬레이션으로 대체)"))
story.append(bullet("Kafka·OpenTelemetry (과제 범위 밖)"))

# --- 3. 시스템 아키텍처 (Top-Down 3-Tier) ---
story.append(Paragraph("3. 시스템 아키텍처 (Top-Down · 3-Tier)", styles["h2"]))
story.append(Paragraph(
    "전체 골격은 <b>3-Tier</b>(Presentation → Application → Data)로 구성하고, 하위 flow는 "
    "프론트 <b>MVP 패턴</b>(View ↔ Presenter ↔ Model), 백엔드 <b>Controller → Service → "
    "Repository</b> 계층으로 그린다. RFP 2.2의 <b>\"규칙=도구, 에이전트=근거 추론\"</b> 원칙에 "
    "따라 결정적 처리(파서·이상 탐지·군집화)는 Tool로, 추론(근거 설명)은 LLM Agent로 분리한다.",
    styles["body"]))
story.append(Spacer(1, 2))
story.append(Paragraph(
    "<font color='#1D4ED8'>■</font> P0(필수) &nbsp;&nbsp; "
    "<font color='#D97706'>■</font> P1(확장) &nbsp;&nbsp; "
    "<font color='#7C3AED'>■</font> LLM Agent(유일한 진짜 에이전트) &nbsp;&nbsp; "
    "<font color='#0D9488'>■</font> FastAPI 게이트웨이", styles["meta"]))
story.append(Spacer(1, 5))
for _fl in arch_diagram():
    story.append(_fl)
story.append(Spacer(1, 6))
story.append(callout(
    "<b>핵심 경로</b> &nbsp; Service &harr; <b>FastAPI</b> &rarr; 로그 파서(Tool) &rarr; 이상 탐지(규칙 Tool) &rarr; "
    "패턴 군집화(알고리즘 Tool) &rarr; <b>근거 설명(LLM Agent)</b> &rarr; 정확도 검증 "
    "&rarr; FastAPI &rarr; 저장·조회(Service)",
    bg=ACCENT, bd=PRIMARY, st="boxwhite"))
story.append(Spacer(1, 5))
story.append(bullet(
    "<b>결정적 단계(파서·이상 탐지·군집화)</b>는 Tool로 구현해 판정의 재현성과 검증 가능성을 "
    "확보한다. → 필수⑤(정확도 검증) 방어."))
story.append(bullet(
    "<b>추론 단계(근거 설명)</b>만 LLM Agent로 구현한다. 이상으로 판정된 항목에 대해 사람이 "
    "읽을 수 있는 근거를 생성한다."))
story.append(bullet(
    "<b>확장 시(P1-7)</b> 1차 탐지와 근거 설명을 다수 에이전트로 나누어 협업시키되, 한 "
    "에이전트가 실패해도 파이프라인 전체가 멈추지 않도록 격리한다."))

# --- 4. 성공 기준 ---
story.append(Paragraph("4. 성공 기준", styles["h2"]))
story.append(Paragraph(
    "아래 5개 항목이 실제로 동작하는지가 평가 기준선이다.", styles["body"]))
story.append(Spacer(1, 3))
crit_rows = [
    ["1", "정상·이상 로그 구분", "운영 로그 입력 시 일관된 기준으로 정상·이상 판정 출력"],
    ["2", "이상 로그 근거 제시",
     "이상 판정 로그마다 \"왜 문제인지\" 사람이 읽을 수 있는 형태로 근거 출력. "
     "<b>단순 출력 여부를 넘어, 근거가 실제 이상 항목(평소 패턴을 벗어난 지점)을 정확히 "
     "지목하는지를 품질 조건으로 본다.</b>"],
    ["3", "반복 패턴 군집화", "같은 성격의 장애 징후를 묶어 패턴 단위로 제시"],
    ["4", "결과 영속 보관·조회", "분석 결과 저장 후 목록·상세 화면에서 재조회 가능"],
    ["5", "정확도 검증",
     "BGL 라벨 데이터로 F1·Precision·Recall 수치를 화면에서 직접 확인 가능"],
]
story.append(make_table(
    ["#", "성공 기준", "충족 조건"], crit_rows,
    [10 * mm, 38 * mm, 122 * mm]))
story.append(Spacer(1, 5))
acc_note = ("<b>정확도 100%가 목표가 아니다.</b> RFP 평가 기준(5조)에 명시된 대로, 어떤 로그가 왜 "
            "문제인지 근거가 명확히 제시되는지가 정확도 수치보다 우선한다.")
if SUBMIT:
    # 제출용: 박스 대신 일반 문단 (원래 기획서 본문 내용)
    story.append(Paragraph(acc_note, styles["body"]))
else:
    story.append(callout(acc_note))

doc.build(story)
print("PDF generated:", OUT)
