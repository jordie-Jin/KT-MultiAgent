# -*- coding: utf-8 -*-
"""
로그 분석 자동화 시스템 · 에이전트 구성도 (1차 · P0 범위)
레이아웃(상 -> 하): ① 에이전트 로봇 실행 씬(좌->우 진행) · ② 단계 진행 바 ·
③ P0 6단계 절차 카드(단계별 세부 처리 설명).
출력: '에이전트 구성도 1차.pdf' + '에이전트 구성도 1차.png'
"""
import os
import math
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont("KR", r"C:/Windows/Fonts/malgun.ttf"))
pdfmetrics.registerFont(TTFont("KRB", r"C:/Windows/Fonts/malgunbd.ttf"))

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
NAME = os.path.join(OUT_DIR, os.environ.get("AGENT_DIAGRAM_NAME", "에이전트 구성도 1차"))

W, H = 1280, 720

# ---- palette (아키텍처 다이어그램과 색 의미 통일) ----
C_INK     = HexColor("#0F172A")
C_SUB     = HexColor("#64748B")
C_ARROW   = HexColor("#475569")
C_LABEL   = HexColor("#334155")
C_P0_FILL = HexColor("#DBEAFE"); C_P0_STK = HexColor("#1D4ED8")   # 결정적 Tool
C_AG_FILL = HexColor("#EDE9FE"); C_AG_STK = HexColor("#7C3AED")   # LLM Agent
C_DS_FILL = HexColor("#DCFCE7"); C_DS_STK = HexColor("#16A34A")   # 데이터/저장

ROBO_BODY = HexColor("#1E293B")
ROBO_HEAD = HexColor("#334155")
ROBO_METAL= HexColor("#94A3B8")
ROBO_EYE  = HexColor("#22D3EE")
ACCENT    = HexColor("#0EA5E9")
ACCENT_LT = HexColor("#7DD3FC")
FOOT      = HexColor("#CBD5E1")

c = canvas.Canvas(NAME + ".pdf", pagesize=(W, H))


# ============================ primitives ============================
def rrect(x, y, w, h, r, fill, stroke, lw=1.4):
    c.setLineWidth(lw)
    if fill is not None:
        c.setFillColor(fill)
    if stroke is not None:
        c.setStrokeColor(stroke)
    c.roundRect(x, y, w, h, r, stroke=1 if stroke else 0, fill=1 if fill else 0)


def text_lines(cx, cy, lines, gap=3):
    heights = [s for (_, _, s, _) in lines]
    total = sum(heights) + gap * (len(lines) - 1)
    y = cy + total / 2.0
    for (t, f, s, col) in lines:
        y -= s
        c.setFont(f, s)
        c.setFillColor(col)
        c.drawCentredString(cx, y, t)
        y -= gap


def arrowhead(x, y, ang, size=9, col=C_ARROW):
    c.setFillColor(col); c.setStrokeColor(col)
    a1 = ang + math.radians(150)
    a2 = ang - math.radians(150)
    p = c.beginPath()
    p.moveTo(x, y)
    p.lineTo(x + size * math.cos(a1), y + size * math.sin(a1))
    p.lineTo(x + size * math.cos(a2), y + size * math.sin(a2))
    p.close()
    c.drawPath(p, fill=1, stroke=0)


# ============================ robot (좌->우 달리기, 전방 기울임) ============================
def robot(cx, gy, s=0.55):
    LEAN = 9.0  # 위로 갈수록 앞(우)으로 기울어 달리는 느낌

    def P(x, y):
        return (cx + (x + (y / 150.0) * LEAN) * s, gy + y * s)

    c.setLineCap(1); c.setLineJoin(1)

    # 속도선 (뒤쪽, 기울임 미적용)
    c.setStrokeColor(ACCENT_LT); c.setLineWidth(3.4 * s)
    for (yy, x0, x1) in [(46, -96, -62), (74, -108, -66), (104, -98, -64)]:
        c.line(cx + x0 * s, gy + yy * s, cx + x1 * s, gy + yy * s)

    # 뒷다리 (밀어내기, 뻗음)
    c.setStrokeColor(ROBO_BODY); c.setLineWidth(12 * s)
    h = P(-2, 46); k = P(-26, 22); f = P(-40, 4)
    c.line(h[0], h[1], k[0], k[1]); c.line(k[0], k[1], f[0], f[1])
    # 앞다리 (들어올림, 굽힘)
    h2 = P(8, 48); k2 = P(30, 34); f2 = P(50, 20)
    c.line(h2[0], h2[1], k2[0], k2[1]); c.line(k2[0], k2[1], f2[0], f2[1])
    # 발
    c.setLineWidth(6 * s)
    c.line(f[0] - 8 * s, f[1], f[0] + 10 * s, f[1])
    c.line(f2[0] - 4 * s, f2[1], f2[0] + 13 * s, f2[1])

    # 몸통
    t = P(2, 74)
    rrect(t[0] - 25 * s, t[1] - 25 * s, 50 * s, 50 * s, 13 * s, ROBO_BODY, None)
    # 가슴 코어
    cc = P(2, 74)
    c.setFillColor(ACCENT); c.circle(cc[0], cc[1], 7 * s, stroke=0, fill=1)
    c.setFillColor(white); c.circle(cc[0], cc[1], 3 * s, stroke=0, fill=1)

    # 뒷팔 (뒤로 스윙)
    c.setStrokeColor(ROBO_HEAD); c.setLineWidth(9.5 * s)
    s1 = P(-14, 92); e1 = P(-36, 84); a1 = P(-48, 96)
    c.line(s1[0], s1[1], e1[0], e1[1]); c.line(e1[0], e1[1], a1[0], a1[1])
    # 앞팔 (앞으로 펌핑)
    s2 = P(18, 94); e2 = P(42, 100); a2 = P(56, 90)
    c.line(s2[0], s2[1], e2[0], e2[1]); c.line(e2[0], e2[1], a2[0], a2[1])
    c.setFillColor(ROBO_METAL)
    for hp in (a1, a2):
        c.circle(hp[0], hp[1], 5.5 * s, stroke=0, fill=1)

    # 목
    c.setStrokeColor(ROBO_METAL); c.setLineWidth(8 * s)
    n0 = P(6, 100); n1 = P(8, 110); c.line(n0[0], n0[1], n1[0], n1[1])

    # 머리
    hd = P(10, 126)
    rrect(hd[0] - 24 * s, hd[1] - 20 * s, 48 * s, 41 * s, 12 * s, ROBO_HEAD, None)
    # 귀(센서)
    c.setFillColor(ROBO_METAL)
    erL = P(-13, 126); erR = P(33, 126)
    c.circle(erL[0], erL[1], 4 * s, stroke=0, fill=1)
    c.circle(erR[0], erR[1], 4 * s, stroke=0, fill=1)
    # 안테나 (뒤로 젖힘)
    c.setStrokeColor(ACCENT); c.setLineWidth(3.2 * s)
    an0 = P(2, 146); an1 = P(-10, 160); c.line(an0[0], an0[1], an1[0], an1[1])
    c.setFillColor(ACCENT); ant = P(-12, 163); c.circle(ant[0], ant[1], 4.2 * s, stroke=0, fill=1)
    # 바이저(스크린)
    vc = P(12, 126)
    rrect(vc[0] - 16 * s, vc[1] - 9 * s, 32 * s, 18 * s, 7 * s, HexColor("#0B1220"), None)
    # 눈 (앞을 향함)
    c.setFillColor(ROBO_EYE)
    ey1 = P(5, 126); ey2 = P(19, 126)
    c.circle(ey1[0], ey1[1], 4.6 * s, stroke=0, fill=1)
    c.circle(ey2[0], ey2[1], 4.6 * s, stroke=0, fill=1)
    c.setFillColor(white)
    c.circle(ey1[0] + 1.4 * s, ey1[1] + 1.2 * s, 1.5 * s, stroke=0, fill=1)
    c.circle(ey2[0] + 1.4 * s, ey2[1] + 1.2 * s, 1.5 * s, stroke=0, fill=1)


def chevron(x, y, size, col, lw):
    c.setStrokeColor(col); c.setLineWidth(lw); c.setLineCap(1)
    c.line(x, y + size, x + size, y)
    c.line(x + size, y, x, y - size)


def footprints(x0, x1, y, n):
    c.setFillColor(FOOT)
    if n <= 1:
        return
    step = (x1 - x0) / (n - 1)
    for i in range(n):
        x = x0 + step * i
        yy = y + (4 if i % 2 else -4)
        c.ellipse(x - 4.5, yy - 2.6, x + 4.5, yy + 2.6, stroke=0, fill=1)


def goal_flag(x, gy, h=66):
    c.setStrokeColor(C_ARROW); c.setLineWidth(2.6)
    top = gy + h
    c.line(x, gy, x, top)
    cols, rows = 4, 3
    cw, ch = 8, 7
    fx, fy = x, top - rows * ch
    for r in range(rows):
        for col in range(cols):
            dark = (r + col) % 2 == 0
            c.setFillColor(C_INK if dark else white)
            c.setStrokeColor(C_ARROW); c.setLineWidth(0.5)
            c.rect(fx + col * cw, fy + r * ch, cw, ch, stroke=1, fill=1)


# ============================ title + legend ============================
c.setFont("KRB", 22); c.setFillColor(C_INK)
c.drawString(40, H - 44, "에이전트 구성도")
c.setFont("KR", 12.5); c.setFillColor(C_SUB)
c.drawString(44, H - 64,
             "1차 · P0 범위 · 결정적 Tool ↔ LLM Agent 단일 파이프라인 — 에이전트가 좌→우 순서로 6단계를 관통")

def legend_item(x, y, fill, stroke, text):
    rrect(x, y, 16, 12, 3, fill, stroke, lw=1.2)
    c.setFont("KR", 10); c.setFillColor(C_INK); c.drawString(x + 22, y + 2, text)

legend_item(812, H - 40, C_P0_FILL, C_P0_STK, "결정적 Tool · P0")
legend_item(812, H - 58, C_AG_FILL, C_AG_STK, "LLM Agent · P0-3")
legend_item(1010, H - 40, C_DS_FILL, C_DS_STK, "데이터 · 저장 · P0-5")
legend_item(1010, H - 58, ROBO_BODY, ROBO_HEAD, "에이전트 · 진행 방향")


# ============================ layout constants ============================
SX = [132, 317, 502, 687, 872, 1057]
P0 = (C_P0_FILL, C_P0_STK)
AG = (C_AG_FILL, C_AG_STK)
DS = (C_DS_FILL, C_DS_STK)

# 단계 데이터: (번호, 제목, 형태, [세부 처리 단계], 출력, 태그, 스타일)
STEPS = [
    (1, "로그 파서",   "결정적 Tool · P0-1",
     ["로그 소스 수신", "정상/이상 라벨 분리", "JSON 정형화", "청크 분할"],
     "정형 로그 청크", "비LLM · 결정적", P0),
    (2, "이상 탐지",   "규칙 Tool · P0-2",
     ["이상 패턴 탐지", "임계값 기반 필터링", "시간 윈도우 분석", "정상/이상 분류"],
     "정상/이상 라벨", "LLM 없음 · 재현가능", P0),
    (3, "패턴 군집화", "알고리즘 Tool · P0-4",
     ["로그 템플릿 추출", "유사 패턴 군집화", "반복 패턴 그루핑"],
     "이상 패턴 군집", "비LLM · 알고리즘", P0),
    (4, "근거 설명",   "LLM Agent · P0-3",
     ["근본 원인 분석", "RAG 기반 추론", "이상 지점 명시", "자연어 근거 생성"],
     "사람이 읽는 근거", "LLM · 진짜 에이전트", AG),
    (5, "저장·조회",   "Service · P0-5",
     ["분석 결과 영속 저장", "목록·상세 조회", "대시보드 제공"],
     "조회 가능 결과", "조직 지식 축적", DS),
    (6, "정확도 검증", "모듈 · P0-6",
     ["라벨 대조 평가", "정밀도·재현율·F1 산출", "결과 화면 표시"],
     "F1·P·R 지표", "평가 기준선", P0),
]

ROBO_X = 412  # 2~3단계 사이


# ===================== ① 에이전트 실행 씬 (상단, 축소) =====================
RX0, RX1 = 60, 1220
RY0, RY1 = 556, 654
GROUND = 558
rrect(RX0, RY0, RX1 - RX0, RY1 - RY0, 14, HexColor("#F1F5F9"), HexColor("#CBD5E1"), lw=1.2)
c.setFont("KRB", 10); c.setFillColor(C_SUB)
c.drawString(RX0 + 14, RY1 - 18, "에이전트 실행 흐름")

# 좌->우 진행 방향 강조: 굵은 화살표 + 셰브론
ay = 600
c.setStrokeColor(ACCENT); c.setLineWidth(4); c.setLineCap(1)
c.line(RX0 + 150, ay, RX1 - 95, ay)
arrowhead(RX1 - 86, ay, 0, size=13, col=ACCENT)
for i, x in enumerate(range(540, 1130, 60)):
    chevron(x, ay, 7, ACCENT_LT, 3)
c.setFont("KRB", 11); c.setFillColor(ACCENT)
c.drawString(RX0 + 150, ay + 12, "진행 방향  좌 → 우")

# START
c.setFont("KRB", 9); c.setFillColor(C_LABEL)
c.drawCentredString(RX0 + 95, GROUND - 2, "START")
c.setFillColor(C_P0_STK); c.circle(RX0 + 95, GROUND + 18, 5, stroke=0, fill=1)

# 발자국 (출발 -> 로봇) / 결승 깃발
footprints(RX0 + 120, ROBO_X - 60, GROUND + 8, 7)
goal_flag(RX1 - 70, GROUND, h=58)
c.setFont("KRB", 9); c.setFillColor(C_LABEL)
c.drawCentredString(RX1 - 52, GROUND - 12, "P0 완주")

# 로봇
robot(ROBO_X, GROUND, s=0.58)
# 현재 위치 콜아웃 (로봇 우측, 밴드 내부)
_lab = "현재 2→3단계"
c.setFont("KRB", 8.8); _tw = c.stringWidth(_lab, "KRB", 8.8); _pw = _tw + 16
rrect(ROBO_X + 52, 610, _pw, 17, 8.5, ACCENT, None)
c.setFillColor(white); c.drawCentredString(ROBO_X + 52 + _pw / 2, 615, _lab)


# ===================== ② 단계 진행 바 (중단) =====================
PBY = 500
c.setFont("KRB", 11); c.setFillColor(C_INK)
c.drawString(60, PBY + 22, "단계 진행 (좌 → 우 실행 순서)")

c.setLineCap(1)
c.setStrokeColor(HexColor("#E2E8F0")); c.setLineWidth(9)
c.line(SX[0], PBY, SX[-1], PBY)
c.setStrokeColor(ACCENT); c.setLineWidth(9)
c.line(SX[0], PBY, ROBO_X, PBY)

for i, sx in enumerate(SX):
    done = sx <= ROBO_X
    code = STEPS[i][2].split(" · ")[-1]
    if done:
        c.setFillColor(ACCENT); c.circle(sx, PBY, 12, stroke=0, fill=1)
        c.setFillColor(white); c.setFont("KRB", 11)
        c.drawCentredString(sx, PBY - 4, str(STEPS[i][0]))
    else:
        c.setFillColor(white); c.setStrokeColor(HexColor("#94A3B8")); c.setLineWidth(2)
        c.circle(sx, PBY, 12, stroke=1, fill=1)
        c.setFillColor(HexColor("#94A3B8")); c.setFont("KRB", 11)
        c.drawCentredString(sx, PBY - 4, str(STEPS[i][0]))
    c.setFont("KRB", 8.4); c.setFillColor(C_LABEL)
    c.drawCentredString(sx, PBY + 20, code)

# 로봇 현재 위치 마커
c.setFillColor(ROBO_BODY); c.circle(ROBO_X, PBY, 6.5, stroke=0, fill=1)
c.setFillColor(ROBO_EYE); c.circle(ROBO_X, PBY, 2.6, stroke=0, fill=1)


# ===================== ③ 절차 카드 (하단, 단계별 세부 설명) =====================
CARD_TOP = 452
CARD_BOT = 100
CW = 170
HEAD_H = 46

def card(sx, num, title, form, bullets, out, tag, style):
    fill, stroke = style
    x = sx - CW / 2
    h = CARD_TOP - CARD_BOT
    # 외곽
    rrect(x, CARD_BOT, CW, h, 11, white, stroke, lw=1.7)
    # 헤더 (색 밴드)
    hy = CARD_TOP - HEAD_H
    rrect(x + 2, hy, CW - 4, HEAD_H - 2, 8, fill, None)
    c.setStrokeColor(stroke); c.setLineWidth(1); c.line(x + 4, hy, x + CW - 4, hy)
    # 제목(원형 번호 포함) · 형태 — 카드 중앙 정렬
    circ = chr(0x245F + num)  # ① ② ③ …
    c.setFont("KRB", 15); c.setFillColor(C_INK)
    c.drawCentredString(sx, CARD_TOP - 20, circ + "  " + title)
    c.setFont("KRB", 10); c.setFillColor(stroke)
    c.drawCentredString(sx, CARD_TOP - 35, form)

    # 세부 처리 단계 — 가운데 정렬
    c.setFont("KRB", 9.5); c.setFillColor(C_SUB)
    c.drawCentredString(sx, hy - 18, "처리 단계")
    c.setStrokeColor(HexColor("#E2E8F0")); c.setLineWidth(0.8)
    c.line(sx - 34, hy - 25, sx + 34, hy - 25)
    by2 = hy - 46
    for b in bullets:
        c.setFont("KR", 14); c.setFillColor(C_LABEL)
        c.drawCentredString(sx, by2, b)
        by2 -= 31

    # 흐름 셰브론 (아래로)
    midy = (by2 + 8 + 188) / 2
    c.setStrokeColor(ACCENT_LT); c.setLineWidth(2); c.setLineCap(1)
    c.line(sx - 6, midy + 5, sx, midy - 1)
    c.line(sx + 6, midy + 5, sx, midy - 1)

    # 출력
    c.setStrokeColor(HexColor("#E2E8F0")); c.setLineWidth(1); c.line(x + 12, 188, x + CW - 12, 188)
    c.setFont("KRB", 11.5); c.setFillColor(ACCENT)
    c.drawCentredString(sx, 168, "▸ 출력 · " + out)

    # 태그 pill — 가운데 정렬
    c.setFont("KRB", 10)
    tw = c.stringWidth(tag, "KRB", 10)
    pw = tw + 20
    rrect(sx - pw / 2, 125, pw, 19, 9.5, None, stroke, lw=1.1)
    c.setFillColor(stroke); c.drawCentredString(sx, 131, tag)


for st in STEPS:
    card(SX[st[0] - 1], st[0], st[1], st[2], st[3], st[4], st[5], st[6])

# 단계 흐름 화살표(카드 사이)
for i in range(5):
    x1 = SX[i] + CW / 2; x2 = SX[i + 1] - CW / 2
    c.setStrokeColor(C_ARROW); c.setLineWidth(1.8); c.setLineCap(1)
    midy = CARD_TOP - 22
    c.line(x1 + 1, midy, x2 - 4, midy)
    arrowhead(x2 - 3, midy, 0, size=7, col=C_ARROW)

# 하단 주석
c.setFont("KR", 8.6); c.setFillColor(C_SUB)
c.drawString(60, 40,
             "※ 6단계는 아키텍처 1차(P0) 핵심 경로의 실행 순서입니다. "
             "로봇 위치(2→3단계)는 에이전트의 진행 흐름을 예시로 표현한 것입니다.")

c.showPage()
c.save()
print("PDF saved:", NAME + ".pdf")

import fitz
doc = fitz.open(NAME + ".pdf")
pix = doc[0].get_pixmap(matrix=fitz.Matrix(3, 3))
pix.save(NAME + ".png")
print("PNG saved:", NAME + ".png", pix.width, "x", pix.height)
