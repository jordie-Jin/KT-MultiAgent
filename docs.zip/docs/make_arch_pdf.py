# -*- coding: utf-8 -*-
"""
로그 분석 자동화 시스템 · 아키텍처 다이어그램 (1차 구현 · P0 범위)
16:9 가로 밴드형 Top-Down 3-Tier 레이아웃. 좌표를 직접 제어해 PPT 한 페이지에
선명하게 들어가도록 구성. 출력: '아키텍처 다이어그램.pdf' + '아키텍처 다이어그램.png'
"""
import math
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont("KR", r"C:/Windows/Fonts/malgun.ttf"))
pdfmetrics.registerFont(TTFont("KRB", r"C:/Windows/Fonts/malgunbd.ttf"))

W, H = 1280, 720
NAME = "아키텍처 다이어그램"

# palette
C_ACTOR   = HexColor("#0F172A")
C_P0_FILL = HexColor("#DBEAFE"); C_P0_STK = HexColor("#1D4ED8")
C_AG_FILL = HexColor("#EDE9FE"); C_AG_STK = HexColor("#7C3AED")
C_GW_FILL = HexColor("#CCFBF1"); C_GW_STK = HexColor("#0D9488")
C_DS_FILL = HexColor("#DCFCE7"); C_DS_STK = HexColor("#16A34A")
C_INK     = HexColor("#0F172A")
C_ARROW   = HexColor("#475569")
C_LABEL   = HexColor("#334155")

BAND = {
    "pres": (HexColor("#F0F9FF"), HexColor("#7DD3FC"), HexColor("#0C4A6E")),
    "app":  (HexColor("#FAFAF9"), HexColor("#D6D3D1"), HexColor("#44403C")),
    "data": (HexColor("#F0FDF4"), HexColor("#86EFAC"), HexColor("#14532D")),
}

c = canvas.Canvas(NAME + ".pdf", pagesize=(W, H))


def rrect(x, y, w, h, r, fill, stroke, lw=1.4):
    c.setLineWidth(lw)
    if fill is not None:
        c.setFillColor(fill)
    if stroke is not None:
        c.setStrokeColor(stroke)
    c.roundRect(x, y, w, h, r, stroke=1 if stroke else 0, fill=1 if fill else 0)


def text_lines(cx, cy, lines):
    """lines: list of (text, font, size, color). vertically centered block."""
    gap = 3
    heights = [s for (_, _, s, _) in lines]
    total = sum(heights) + gap * (len(lines) - 1)
    y = cy + total / 2.0
    for (t, f, s, col) in lines:
        y -= s
        c.setFont(f, s)
        c.setFillColor(col)
        c.drawCentredString(cx, y, t)
        y -= gap


def box(cx, cy, w, h, title, sub, fill, stroke, title_col=C_INK, sub_col=HexColor("#475569"), r=9):
    rrect(cx - w / 2, cy - h / 2, w, h, r, fill, stroke)
    lines = [(title, "KRB", 12.5, title_col)]
    if sub:
        lines.append((sub, "KR", 9.5, sub_col))
    text_lines(cx, cy, lines)


def cylinder(cx, cy, w, h, title, sub, fill, stroke):
    left, right = cx - w / 2, cx + w / 2
    top, bot = cy + h / 2, cy - h / 2
    ry = 9
    c.setLineWidth(1.4); c.setStrokeColor(stroke); c.setFillColor(fill)
    # body
    c.rect(left, bot + ry, w, (top - ry) - (bot + ry), stroke=0, fill=1)
    # bottom ellipse
    c.ellipse(left, bot, right, bot + 2 * ry, stroke=1, fill=1)
    # side lines
    c.line(left, bot + ry, left, top - ry)
    c.line(right, bot + ry, right, top - ry)
    # top ellipse (over body)
    c.ellipse(left, top - 2 * ry, right, top, stroke=1, fill=1)
    lines = [(title, "KRB", 12, C_INK)]
    if sub:
        lines.append((sub, "KR", 9.5, HexColor("#475569")))
    text_lines(cx, cy - 2, lines)


def arrowhead(x, y, ang, size=9):
    c.setFillColor(C_ARROW); c.setStrokeColor(C_ARROW)
    a1 = ang + math.radians(150)
    a2 = ang - math.radians(150)
    p = c.beginPath()
    p.moveTo(x, y)
    p.lineTo(x + size * math.cos(a1), y + size * math.sin(a1))
    p.lineTo(x + size * math.cos(a2), y + size * math.sin(a2))
    p.close()
    c.drawPath(p, fill=1, stroke=0)


def poly(points, label=None, lab_xy=None, dashed=False, lw=1.6, both=False):
    c.setLineWidth(lw); c.setStrokeColor(C_ARROW)
    c.setDash(4, 3) if dashed else c.setDash()
    pth = c.beginPath()
    pth.moveTo(*points[0])
    for pt in points[1:]:
        pth.lineTo(*pt)
    c.drawPath(pth, fill=0, stroke=1)
    c.setDash()
    x1, y1 = points[-2]; x2, y2 = points[-1]
    arrowhead(x2, y2, math.atan2(y2 - y1, x2 - x1))
    if both:
        bx1, by1 = points[1]; bx0, by0 = points[0]
        arrowhead(bx0, by0, math.atan2(by0 - by1, bx0 - bx1))
    if label:
        lx, ly = lab_xy if lab_xy else ((x1 + x2) / 2, (y1 + y2) / 2)
        c.setFont("KRB", 9.5);
        tw = c.stringWidth(label, "KRB", 9.5)
        c.setFillColor(white); c.rect(lx - tw / 2 - 3, ly - 2, tw + 6, 13, stroke=0, fill=1)
        c.setFillColor(C_LABEL); c.drawCentredString(lx, ly + 1.5, label)


def band(x, y, w, h, key, label):
    bg, stk, txt = BAND[key]
    rrect(x, y, w, h, 14, bg, stk, lw=1.2)
    c.setFont("KRB", 12); c.setFillColor(txt)
    c.drawString(x + 16, y + h - 18, label)


# ---------- title ----------
c.setFont("KRB", 21); c.setFillColor(C_INK)
c.drawString(40, H - 42, "로그 분석 자동화 시스템 — 아키텍처")
c.setFont("KR", 12.5); c.setFillColor(HexColor("#64748B"))
c.drawString(44, H - 60, "1차 구현 설계 · P0 범위 · Top-Down 3-Tier (하위 흐름 MVP / Controller–Service–Repository)")

# ---------- legend (top-right) ----------
def legend_item(x, y, fill, stroke, text):
    rrect(x, y, 16, 12, 3, fill, stroke, lw=1.2)
    c.setFont("KR", 10); c.setFillColor(C_INK); c.drawString(x + 22, y + 2, text)

legend_item(820, H - 40, C_P0_FILL, C_P0_STK, "결정적 Tool · 일반 P0")
legend_item(820, H - 58, C_AG_FILL, C_AG_STK, "LLM Agent (근거 추론)")
legend_item(1015, H - 40, C_GW_FILL, C_GW_STK, "FastAPI 게이트웨이")
legend_item(1015, H - 58, C_DS_FILL, C_DS_STK, "데이터 저장소")

# ================= TIER BANDS =================
band(120, 550, 1040, 84, "pres", "① Presentation Tier · React 대시보드 (MVP 패턴)")
band(70, 250, 1140, 286, "app", "② Application Tier")
band(120, 92,  1040, 150, "data", "③ Data Tier")

# ---------- actor ----------
box(640, 662, 150, 30, "사용자 · 운영자", "", C_ACTOR, C_ACTOR, title_col=white, r=15)

# ---------- Presentation boxes ----------
pV = (420, 578); pP = (640, 578); pM = (860, 578)
box(*pV, 180, 50, "View", "대시보드·목록·상세 화면", C_P0_FILL, C_P0_STK)
box(*pP, 180, 50, "Presenter", "표시·이벤트 조율", C_P0_FILL, C_P0_STK)
box(*pM, 180, 50, "Model", "API 응답 모델", C_P0_FILL, C_P0_STK)
# internal MVP double arrows
poly([(pV[0] + 90, pV[1]), (pP[0] - 90, pP[1])])
poly([(pP[0] - 90, pP[1] - 0), (pV[0] + 90, pV[1])])  # back
poly([(pP[0] + 90, pP[1]), (pM[0] - 90, pM[1])])
poly([(pM[0] - 90, pM[1]), (pP[0] + 90, pP[1])])  # back

# ---------- Application: Spring Boot cluster ----------
rrect(360, 452, 560, 78, 10, white, HexColor("#CBD5E1"), lw=1.2)
c.setFont("KRB", 10.5); c.setFillColor(HexColor("#475569"))
c.drawString(372, 510, "Spring Boot API · Controller → Service → Repository")
sC = (460, 478); sS = (640, 478); sR = (820, 478)
box(*sC, 168, 40, "Controller", "대시보드·목록·상세·정확도 API", C_P0_FILL, C_P0_STK, r=7)
box(*sS, 168, 40, "Service", "분석 오케스트레이션·조회", C_P0_FILL, C_P0_STK, r=7)
box(*sR, 168, 40, "Repository", "RDBMS 접근", C_P0_FILL, C_P0_STK, r=7)
poly([(sC[0] + 84, sC[1]), (sS[0] - 84, sS[1])])
poly([(sS[0] + 84, sS[1]), (sR[0] - 84, sR[1])])

# ---------- Application: Python engine cluster (FastAPI 게이트웨이 + Tool/Agent) ----------
rrect(100, 286, 1080, 130, 10, white, HexColor("#CBD5E1"), lw=1.2)
c.setFont("KRB", 10.5); c.setFillColor(HexColor("#475569"))
c.drawString(112, 396, "Python 분석 엔진 · FastAPI 게이트웨이 → 결정적 Tool ↔ LLM Agent")
yP = 340
fa = (180, yP)
e1 = (365, yP); e2 = (547, yP); e3 = (730, yP); e4 = (912, yP); e5 = (1094, yP)
EW = 160  # pipeline box width
box(*fa, 150, 58, "FastAPI", "분석 요청 엔드포인트", C_GW_FILL, C_GW_STK)
box(*e1, EW, 58, "로그 파서", "Tool · P0-1", C_P0_FILL, C_P0_STK)
box(*e2, EW, 58, "이상 탐지", "규칙 Tool · P0-2", C_P0_FILL, C_P0_STK)
box(*e3, EW, 58, "패턴 군집화", "알고리즘 Tool · P0-4", C_P0_FILL, C_P0_STK)
box(*e4, EW, 58, "근거 설명", "LLM Agent · P0-3", C_AG_FILL, C_AG_STK)
box(*e5, EW, 58, "정확도 검증", "모듈 · P0-6", C_P0_FILL, C_P0_STK)
poly([(fa[0] + 75, yP), (e1[0] - EW / 2, yP)])           # FastAPI -> 로그파서
poly([(e1[0] + EW / 2, yP), (e2[0] - EW / 2, yP)])
poly([(e2[0] + EW / 2, yP), (e3[0] - EW / 2, yP)])
poly([(e3[0] + EW / 2, yP), (e4[0] - EW / 2, yP)])
poly([(e4[0] + EW / 2, yP), (e5[0] - EW / 2, yP)])
# 정확도검증 -> FastAPI (분석 결과 집계, 파이프라인 하단 경유)
poly([(e5[0], 311), (e5[0], 298), (fa[0], 298), (fa[0], 311)], label="결과 집계", lab_xy=(560, 304))

# ---------- Data boxes ----------
dBGL = (360, 150); dDB = (900, 150)
cylinder(*dBGL, 220, 78, "BGL 로그 입력", "라벨 포함", C_DS_FILL, C_DS_STK)
cylinder(*dDB, 220, 78, "RDBMS", "분석결과 영속 · P0-5", C_DS_FILL, C_DS_STK)

# ================= CROSS-TIER FLOWS =================
RIGHT_LANE = 1168  # vertical routing lane, right of the 정확도검증(P0-6) box
# User -> Presenter
poly([(640, 647), (640, 603)])
# Presentation -> Spring Boot (REST API)
poly([(640, 554), (640, 530)], label="REST API", lab_xy=(640, 543))
# Service <-> FastAPI (분석 요청 / 응답): Spring Boot가 FastAPI를 통해 분석 호출·결과 수신
poly([(sS[0], 458), (sS[0], 426), (fa[0], 426), (fa[0], 369)],
     label="분석 요청 / 응답", lab_xy=(430, 432), both=True)
# Repository -> RDBMS (영속): right margin lane down
poly([(sR[0], 458), (sR[0], 446), (RIGHT_LANE, 446), (RIGHT_LANE, 150), (dDB[0] + 110, 150)],
     label="분석결과 영속", lab_xy=(RIGHT_LANE, 300))
# BGL -> Parser (로그 입력)
poly([(dBGL[0], 189), (dBGL[0], 240), (e1[0], 240), (e1[0], 311)], label="로그 입력", lab_xy=(dBGL[0] - 50, 250))

c.showPage()
c.save()
print("PDF saved:", NAME + ".pdf")

# ---------- PDF -> PNG (high-res for PPT) ----------
import fitz  # PyMuPDF
doc = fitz.open(NAME + ".pdf")
pix = doc[0].get_pixmap(matrix=fitz.Matrix(3, 3))
pix.save(NAME + ".png")
print("PNG saved:", NAME + ".png", pix.width, "x", pix.height)
